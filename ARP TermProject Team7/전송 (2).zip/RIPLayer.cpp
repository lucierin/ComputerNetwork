#include "StdAfx.h"
#include "RIPLayer.h"


RIPLayer::RIPLayer(void)
{
}


RIPLayer::~RIPLayer(void)
{
}
